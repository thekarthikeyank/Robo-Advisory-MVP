═══════════════════════════════════════════════════════════════
  AHAM MASTER WORKFLOW — QUICK SETUP
  Karthikeyan K. · Financial Systems & Business Automation
═══════════════════════════════════════════════════════════════

FILES IN THIS ZIP
─────────────────
  AHAM_Master_Workflow.json        ← Single n8n workflow (import this)
  frontend/
    ├── App.jsx                    ← React SPA (copy into src/)
    ├── src/App.jsx                ← Same file already placed here
    ├── src/main.jsx               ← React entry point
    ├── index.html                 ← Vite entry
    ├── package.json               ← Dependencies
    ├── vite.config.js             ← Build config
    └── google_apps_script.js      ← Paste into Google Apps Script

─────────────────────────────────────────────────────────────
HOW THE MASTER WORKFLOW WORKS
─────────────────────────────────────────────────────────────

  One trigger (every minute) → Orchestration Router decides:

  Every minute  → Check Google Sheet for new rows → send onboarding email
  Monday 8AM    → Fetch NIFTY/Gold/NASDAQ → send weekly market pulse
  1st of month  → Check 6-month clients  → send reassessment email

─────────────────────────────────────────────────────────────
STEP 1 — Google Sheet (2 min)
─────────────────────────────────────────────────────────────
  Create new Google Sheet
  Name a tab: AHAM_Leads
  Copy the sheet URL

─────────────────────────────────────────────────────────────
STEP 2 — Apps Script (5 min)
─────────────────────────────────────────────────────────────
  Inside your Sheet → Extensions → Apps Script
  Paste: google_apps_script.js
  Deploy → Web App → Anyone → Copy URL

─────────────────────────────────────────────────────────────
STEP 3 — Update App.jsx (30 sec)
─────────────────────────────────────────────────────────────
  Line 4:
  const APPS_SCRIPT_URL = "YOUR_APPS_SCRIPT_URL_HERE";
  → Replace with your Apps Script URL

─────────────────────────────────────────────────────────────
STEP 4 — Deploy to Vercel (10 min)
─────────────────────────────────────────────────────────────
  cd frontend
  npm install
  npm run build
  vercel   ← installs with: npm install -g vercel

─────────────────────────────────────────────────────────────
STEP 5 — Import to n8n (5 min)
─────────────────────────────────────────────────────────────
  Open http://localhost:5678
  Workflows → Import → AHAM_Master_Workflow.json

  REPLACE THESE 4 PLACEHOLDERS in the workflow:
  ┌─────────────────────────────────────────────────────────┐
  │ YOUR_GOOGLE_SHEET_URL_HERE  → paste your sheet URL (x3) │
  │ YOUR_GOOGLE_OAUTH_CRED_ID   → from n8n credentials      │
  │ YOUR_GMAIL_OAUTH_CRED_ID    → from n8n credentials      │
  │ YOUR_VERCEL_FORM_URL_HERE   → your vercel.app URL        │
  └─────────────────────────────────────────────────────────┘

  Activate workflow → done.

─────────────────────────────────────────────────────────────
TEST IT
─────────────────────────────────────────────────────────────
  1. Open your Vercel URL
  2. Fill the form with your own email
  3. Submit
  4. Wait ~1 minute
  5. Check your inbox for the AHAM Portfolio Report email

═══════════════════════════════════════════════════════════════
  AHAM v2.0 · Total cost: ₹0 · All values in INR
═══════════════════════════════════════════════════════════════
