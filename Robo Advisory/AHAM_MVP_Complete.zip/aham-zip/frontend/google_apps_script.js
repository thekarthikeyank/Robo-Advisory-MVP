// ═══════════════════════════════════════════════════════════════════
// AHAM — Google Apps Script
// Karthikeyan K. · Financial Systems & Business Automation
// ═══════════════════════════════════════════════════════════════════
//
// SETUP INSTRUCTIONS:
// 1. Open your Google Sheet
// 2. Extensions → Apps Script
// 3. Delete everything, paste this entire file
// 4. Save (Ctrl+S)
// 5. Deploy → New Deployment → Web App
//    - Execute as: Me
//    - Who has access: Anyone
// 6. Click Deploy → Copy the Web App URL
// 7. Paste that URL into App.jsx as APPS_SCRIPT_URL
// ═══════════════════════════════════════════════════════════════════

const SHEET_NAME = "AHAM_Leads";

// Column headers — will be created automatically on first submission
const HEADERS = [
  "Timestamp",
  "Name",
  "Email",
  "Phone",
  "Investment",
  "Target Years",
  "Horizon",
  "Income",
  "Wealth",
  "Reaction",
  "Experience",
  "Goal",
  "Returns",
  "Risk Score",
  "Risk Profile",
  "CAGR",
  "Projection",
  "Processed"   // n8n will mark this as TRUE after email sent
];

function doPost(e) {
  try {
    // Parse incoming JSON from React form
    const data = JSON.parse(e.postData.contents);

    // Get or create the sheet
    const ss    = SpreadsheetApp.getActiveSpreadsheet();
    let sheet   = ss.getSheetByName(SHEET_NAME);

    // Create sheet with headers if it doesn't exist yet
    if (!sheet) {
      sheet = ss.insertSheet(SHEET_NAME);
      sheet.appendRow(HEADERS);

      // Style the header row
      const headerRange = sheet.getRange(1, 1, 1, HEADERS.length);
      headerRange.setBackground("#0e1420");
      headerRange.setFontColor("#c9a84c");
      headerRange.setFontWeight("bold");
      sheet.setFrozenRows(1);
    }

    // Build the row in the same order as HEADERS
    const row = [
      new Date().toLocaleString("en-IN"),   // Timestamp
      data.name           || "",
      data.email          || "",
      data.phone          || "",
      data.investment     || "",
      data.targetYears    || "",
      data.horizon        || "",
      data.income         || "",
      data.wealth         || "",
      data.reaction       || "",
      data.experience     || "",
      data.goal           || "",
      data.returns        || "",
      data.riskScore      || "",
      data.riskProfile    || "",
      data.cagr           || "",
      data.projection     || "",
      "FALSE"                               // Processed = FALSE until n8n runs
    ];

    sheet.appendRow(row);

    // Return success
    return ContentService
      .createTextOutput(JSON.stringify({ status: "success" }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    // Return error (won't show to user but logs to Apps Script console)
    return ContentService
      .createTextOutput(JSON.stringify({ status: "error", message: err.message }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// Test function — run this manually to verify sheet is working
function testSheet() {
  const testData = {
    postData: {
      contents: JSON.stringify({
        name: "Test User",
        email: "test@example.com",
        phone: "9876543210",
        investment: "500000",
        targetYears: "10",
        horizon: "high",
        income: "high",
        wealth: "medium",
        reaction: "high",
        experience: "medium",
        goal: "high",
        returns: "high",
        riskScore: 19,
        riskProfile: "Aggressive",
        cagr: "19-25%",
        projection: "₹45.2 L"
      })
    }
  };
  doPost(testData);
  Logger.log("Test row added to sheet successfully");
}
